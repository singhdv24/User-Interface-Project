<script>
  import { onMount } from 'svelte';
  import { Chart, registerables } from 'chart.js/auto';
  
  // Register the necessary components
  Chart.register(...registerables);

  let moodData = [];
  let moodLabels = [];

  // Function to add mood
  function addMood(mood) {
      if (mood) {
          moodData.push(mood);
          moodLabels.push(new Date().toLocaleDateString());
          updateMoodChart();
      }
  }

  // Update the chart with mood data
  let moodChart;

  function updateMoodChart() {
      if (moodChart) {
          moodChart.destroy();
      }

      const ctx = document.getElementById('moodChart').getContext('2d');
      moodChart = new Chart(ctx, {
          type: 'line',
          data: {
              labels: moodLabels,
              datasets: [{
                  label: 'Mood Tracking',
                  data: moodData.map(mood => mood === "happy" ? 1 : mood === "sad" ? 0 : mood === "anxious" ? -1 : 2),
                  borderColor: 'rgba(75, 192, 192, 1)',
                  borderWidth: 2,
                  fill: false,
              }]
          },
          options: {
              responsive: true,
              scales: {
                  y: {
                      beginAtZero: true,
                      ticks: {
                          callback: function(value) {
                              return value === 1 ? 'Happy' : value === 0 ? 'Sad' : value === -1 ? 'Anxious' : 'Motivated';
                          }
                      }
                  }
              }
          }
      });
  }

  // Display a random quote from an array
  const quotes = [
      "The only way to do great work is to love what you do. - Steve Jobs",
      "You are enough just as you are. - Bridget Jones",
      // Add more quotes as needed
  ];

  let currentQuote = quotes[0];

  function displayRandomQuote() {
      const randomIndex = Math.floor(Math.random() * quotes.length);
      currentQuote = quotes[randomIndex];
  }

  // Change theme function
  let theme = 'default';

  function changeTheme(event) {
      theme = event.target.value;
      document.body.className = theme;
  }
</script>

<div class="container">
  <header>
      <h1>Mental Health Tracker</h1>
      <p>Reflect on your feelings, practice gratitude, and set self-care goals.</p>
  </header>
  <main>
      <section id="mood-tracker">
          <h2>Track Your Mood</h2>
          <label for="mood-select">Select Your Mood:</label>
          <select id="mood-select" on:change="{(e) => addMood(e.target.value)}">
              <option value="">Select</option>
              <option value="happy">Happy</option>
              <option value="sad">Sad</option>
              <option value="anxious">Anxious</option>
              <option value="motivated">Motivated</option>
          </select>
          <ul>
              {#each moodData as mood}
                  <li>{mood}</li>
              {/each}
          </ul>
          <canvas id="moodChart" width="400" height="200"></canvas>
      </section>

      <section id="inspirational-quotes">
          <h2>Inspirational Quotes</h2>
          <p>{currentQuote}</p>
          <button on:click="{displayRandomQuote}">New Quote</button>
      </section>

      <section id="theme-selection">
          <h2>Choose a Theme</h2>
          <select id="theme-select" on:change="{changeTheme}">
              <option value="default">Default</option>
              <option value="dark">Dark</option>
              <option value="light">Light</option>
          </select>
      </section>
  </main>
</div>


<style>
  body {
      font-family: Arial, sans-serif;
      background-color: #f0f8ff;
      color: #333;
      margin: 0;
      padding: 20px;
  }

  .container {
      max-width: 800px;
      margin: auto;
      padding: 20px;
      border-radius: 8px;
      background-color: #ffffff;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  }

  header {
      text-align: center;
      margin-bottom: 20px;
  }

  h1 {
      color: #4a90e2;
  }

  h2 {
      color: #333;
  }

  section {
      margin-bottom: 20px;
  }

  input, select, textarea {
      width: 70%;
      padding: 10px;
      margin-right: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
  }

  button {
      padding: 10px 15px;
      background-color: #4a90e2;
      color: rgb(255, 255, 255);
      border: none;
      border-radius: 4px;
      cursor: pointer;
  }

  button:hover {
      background-color: #357ab8;
  }

  ul {
      list-style-type: none;
      padding: 0;
  }

  li {
      padding: 5px;
      background-color: #e0f7fa;
      border-radius: 4px;
      margin: 5px 0;
  }

  textarea {
      width: 100%;
      height: 100px;
  }
</style>
